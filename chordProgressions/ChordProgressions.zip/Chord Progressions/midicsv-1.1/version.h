
#define VERSION "1.1 (January 2008)"
