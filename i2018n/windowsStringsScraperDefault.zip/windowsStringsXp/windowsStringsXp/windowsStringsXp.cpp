// windowsStrings3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include <atlbase.h>
#include <iostream>
#include <fstream>

#include <string>
#include <locale>

using namespace std;

LPCWSTR FindStringResourceEx(HINSTANCE hinst,
    UINT uId, UINT langId)
{
    // Convert the string ID into a bundle number
    LPCWSTR pwsz = NULL;
    HRSRC hrsrc = FindResourceEx(hinst, RT_STRING,
        MAKEINTRESOURCE(uId / 16 + 1),
        langId);
    if (hrsrc) {
        HGLOBAL hglob = LoadResource(hinst, hrsrc);
        if (hglob) {
            pwsz = reinterpret_cast<LPCWSTR>
                (LockResource(hglob));
            if (pwsz) {
                // okay now walk the string table
                for (int i = 0; i < (uId & 15); i++) {
                    pwsz += 1 + (UINT)*pwsz;
                }

                pwsz+= 1;
            }
        }
    }
    return pwsz;
}

UINT FindResourceStringId(HMODULE resource_handle, LPCWSTR string, UINT langId)
{
    UINT resource_id= -1;

    for (int i= 0; i<65536; ++i)
    {
        LPCWSTR resource_string= FindStringResourceEx(resource_handle, i, langId);

        if (resource_string && wcsncmp(resource_string, string, wcslen(string))==0)
        {
            resource_id= i;
        }
    }

    return resource_id;
}

std::string wstrtostr(const std::wstring &wstr)
{
    std::string strTo;
    char *szTo = new char[wstr.length() + 1];
    szTo[wstr.size()] = '\0';
    WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), -1, szTo, (int)wstr.length(), NULL, NULL);
    strTo = szTo;
    delete[] szTo;
    return strTo;
}


string convLPCWSTRtoString(LPCWSTR wString)
{
    wstring tempWstring(wString);
    string tempString(tempWstring.begin(), tempWstring.end());
    return tempString;
}


std::string to_utf8(const wchar_t* buffer, int len)
{
        int nChars = ::WideCharToMultiByte(
                CP_UTF8,
                0,
                buffer,
                len,
                NULL,
                0,
                NULL,
                NULL);
        if (nChars == 0) return "";

        string newbuffer;
        newbuffer.resize(nChars) ;
        ::WideCharToMultiByte(
                CP_UTF8,
                0,
                buffer,
                len,
                const_cast< char* >(newbuffer.c_str()),
                nChars,
                NULL,
                NULL); 

        return newbuffer;
}

std::string to_utf8(const std::wstring& str)
{
        return to_utf8(str.c_str(), (int)str.size());
}

int main()
{
    HMODULE shell_handle= LoadLibraryW(L"shell32.dll");

    //HMODULE shell_handle= LoadLibraryW(L"shell32Windows2000.dll");
	
	UINT thisLangId = GetSystemDefaultLangID();

    UINT new_folder_id= FindResourceStringId(shell_handle, L"New Folder", thisLangId); // look for US English "New Folder" resource id.
	//std::wcout << new_folder_id << std::endl;
	cout << new_folder_id << std::endl;

	//std::ofstream file("stringsExport.txt");
	
	
	std::ofstream testFile;
	testFile.open("stringsExport.txt", std::ios::out | std::ios::binary); 

	
			testFile << "thisLangId~" << thisLangId << endl;

    for (int i= 0; i < 65536; ++i)
    {
        LPCWSTR resource_string= FindStringResourceEx(shell_handle, i, thisLangId);


		//char* chr = strdup(stdStringResource.c_str());

		if (resource_string != NULL)
        {
			
			
			std::wstring text = resource_string;

			std::string outtext = to_utf8(text);

			testFile << i << "~" << outtext << endl;

			
		}

		//std::string thisString = convLPCWSTRtoString(resource_string);
		//file << thisString.c_str() << endl; 

		//std::wofstream f(L"stringsExport.txt");
		//f << thisString;
		//f.close();

		//free(chr); 

		//ofstream fout("stringsExport.txt");
		//fout << resource_string << endl;
		//fout << i << endl;
		//fout.close();

    }

	testFile.close();

	//ofstream fout("stringsExport.txt");
	//fout << new_folder_id << endl;
	//fout.close();


	return 0;
}