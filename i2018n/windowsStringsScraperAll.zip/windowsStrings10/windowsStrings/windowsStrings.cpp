// windowsStrings3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include <atlbase.h>
#include <iostream>
#include <fstream>
#include <sstream>

#include <list>

#include <vector>

#include <string>
#include <locale>

using namespace std;

struct Language
{
	int id;
	std::string name;
 
	Language(int languageId, std::string languageName) :
			id(languageId), name(languageName)
	{
	}
};

LPCWSTR FindStringResourceEx(HINSTANCE hinst,
    UINT uId, UINT langId)
{
    // Convert the string ID into a bundle number
    LPCWSTR pwsz = NULL;
    HRSRC hrsrc = FindResourceEx(hinst, RT_STRING,
        MAKEINTRESOURCE(uId / 16 + 1),
        langId);
    if (hrsrc) {
        HGLOBAL hglob = LoadResource(hinst, hrsrc);
        if (hglob) {
            pwsz = reinterpret_cast<LPCWSTR>
                (LockResource(hglob));
            if (pwsz) {
                // okay now walk the string table
                for (int i = 0; i < (uId & 15); i++) {
                    pwsz += 1 + (UINT)*pwsz;
                }

                pwsz+= 1;
            }
        }
    }
    return pwsz;
}

UINT FindResourceStringId(HMODULE resource_handle, LPCWSTR string, UINT langId)
{
    UINT resource_id= -1;

    for (int i= 0; i<65536; ++i)
    {
        LPCWSTR resource_string= FindStringResourceEx(resource_handle, i, langId);

        if (resource_string && wcsncmp(resource_string, string, wcslen(string))==0)
        {
            resource_id= i;
        }
    }

    return resource_id;
}

std::string wstrtostr(const std::wstring &wstr)
{
    std::string strTo;
    char *szTo = new char[wstr.length() + 1];
    szTo[wstr.size()] = '\0';
    WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), -1, szTo, (int)wstr.length(), NULL, NULL);
    strTo = szTo;
    delete[] szTo;
    return strTo;
}


string convLPCWSTRtoString(LPCWSTR wString)
{
    wstring tempWstring(wString);
    string tempString(tempWstring.begin(), tempWstring.end());
    return tempString;
}


std::string to_utf8(const wchar_t* buffer, int len)
{
        int nChars = ::WideCharToMultiByte(
                CP_UTF8,
                0,
                buffer,
                len,
                NULL,
                0,
                NULL,
                NULL);
        if (nChars == 0) return "";

        string newbuffer;
        newbuffer.resize(nChars) ;
        ::WideCharToMultiByte(
                CP_UTF8,
                0,
                buffer,
                len,
                const_cast< char* >(newbuffer.c_str()),
                nChars,
                NULL,
                NULL); 

        return newbuffer;
}

std::string to_utf8(const std::wstring& str)
{
        return to_utf8(str.c_str(), (int)str.size());
}

int main()
{
    HMODULE shell_handle= LoadLibraryW(L"shell32.dll");

    //HMODULE shell_handle= LoadLibraryW(L"shell32Windows2000.dll");
	

	//std::list<UINT> theseLangIds(0x0481, 0x404);

	//std::vector<UINT> theseLangIds(0x0481, 0x404);
	
	UINT theseLangIds[] = {0x046a, 0x0488, 0x0452, 0x042a, 0x0803, 0x0443, 0x0436, 0x041c, 0x045e, 0x042b, 0x044d, 0x042c, 0x0845, 0x0445, 0x042d, 0x0423, 0x141a, 0x0403, 0x0492, 0x045c, 0x048c, 0x0464, 0x0456, 0x0437, 0x0447, 0x0468, 0x0439, 0x040f, 0x0470, 0x0421, 0x083c, 0x0434, 0x0435, 0x0486, 0x044b, 0x043f, 0x0453, 0x0487, 0x0441, 0x0457, 0x0440, 0x0454, 0x046e, 0x042f, 0x043e, 0x044c, 0x043a, 0x0481, 0x044e, 0x0450, 0x0461, 0x0814, 0x0429, 0x0448, 0x0446, 0x0846, 0x0c6b, 0x0491, 0x046c, 0x0859, 0x045b, 0x0428, 0x0449, 0x0444, 0x044a, 0x0473, 0x0442, 0x0420, 0x0480};

	int numberLangs = sizeof(theseLangIds) / sizeof(theseLangIds[0]);

	for (int currentLang = 0; currentLang < numberLangs; currentLang++) 
	{
		UINT thisLangId = theseLangIds[currentLang];

		//UINT thisLangId = GetSystemDefaultLangID();
		//UINT thisLangId = 0x0481;

		//UINT new_folder_id= FindResourceStringId(shell_handle, L"New Folder", thisLangId); // look for US English "New Folder" resource id.
		//std::wcout << new_folder_id << std::endl;
		//cout << new_folder_id << std::endl;
		cout << thisLangId << std::endl;

		//std::ofstream file("stringsExport.txt");
	
		string thisLangString = "";

		stringstream ss;

		ss << "stringsExport_" << thisLangId << ".txt";
		thisLangString = ss.str();

		ss.str("");
	
		std::ofstream testFile;
		testFile.open(thisLangString, std::ios::out | std::ios::binary); 

	
		testFile << "thisLangId~" << thisLangId << endl;

		for (int i= 0; i < 65536; ++i)
		{
		   LPCWSTR resource_string= FindStringResourceEx(shell_handle, i, thisLangId);


			//char* chr = strdup(stdStringResource.c_str());

			if (resource_string != NULL)
			{
			
			
				std::wstring text = resource_string;

				std::string outtext = to_utf8(text);

				testFile << "<key>" << i << "</key><string>" << outtext << "</string>" << endl;

			
			}

			//std::string thisString = convLPCWSTRtoString(resource_string);
			//file << thisString.c_str() << endl; 

			//std::wofstream f(L"stringsExport.txt");
			//f << thisString;
			//f.close();

			//free(chr); 

			//ofstream fout("stringsExport.txt");
			//fout << resource_string << endl;
			//fout << i << endl;
			//fout.close();

		}

		testFile.close();

		//ofstream fout("stringsExport.txt");
		//fout << new_folder_id << endl;
		//fout.close();
	}

	return 0;
}